[x,y]=meshgrid(-10:.1:10,-10:.1:10);

f=x.^2+y.^2;
surf(x,y,f)
x0=9;
y0=9;

x=x0;
y=y0;

eta=0.01;
itr=1;
maxIter=100;

hold on
while itr<maxIter
dx=2*x;
dy=2*y;
x=x-eta*dx;;
y=y-eta*dy;
f=x.^2+y.^2;
plot3(x,y,f,'om','LineWidth',6,'MarkerSize',5)

itr=itr+1;
end
hold on
hold off
