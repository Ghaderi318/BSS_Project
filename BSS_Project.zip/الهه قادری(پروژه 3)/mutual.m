[s1,Fs]=audioread('e.wav');
sound(s1,Fs)
pause(6)
[s2,Fs]=audioread('g.wav');
sound(s2,Fs)
pause(6)
[s3,Fs]=audioread('r.wav');

sound(s3,Fs)
pause(6)
MinimumLength=min([length(s1),length(s2),length(s3)]);
s1=s1(1:MinimumLength);
s2=s2(1:MinimumLength);
s3=s3(1:MinimumLength);
x1=2.*s1+s2+3.*s3;
x2=3.*s1;
x3=-4.*s1+2.*s2+s3;
X=[x1;x2;x3];
A=[2,1,3;3,0,0;-4,2,1];
  s=[s1;s2;s3];

sound(x1)
pause(6)
sound(x2)
pause(6)
sound(x3)
pause(6)
s=ones(3);
B=diag(diag(s));
b=inv(B);
L=length(X)*0.00001;
pause(22)
n=ceil(L);
x=rand(n,3);

y=x;
T=80;
iter=0;
Mu=.25;
  while iter<=T
K=[y.^2;y.^3;y.^4];
KT=K';
Dk=[2*y;3*y.^2;4*y.^3];

S1=1/T*Dk;

S2=1/T*K*KT;

teta=inv(S2)*S1;

W=KT*teta;
u=W*x';

DI=0.1*u-b';

B=B-Mu*(u-DI);

C=A*B;
y=B*x;
iter=iter+1;
  end
  S=inv(y)*X;
   y1=S(1,:);
  sound(y1,Fs)
  pause(6)
  y2=S(2,:);
  sound(y2,Fs)
  pause(6)
  y3=S(3,:);
  sound(y3,Fs)

 