R=[1 4 0; 4 2 1; 0 1 3];

[U,S,V]=svd(R,'econ');

s=diag(S);

    R=U*S*V';
    
mu=0;

sigma=1;

x=mu+sigma*randn(3,1);


rank_R=nnz(s);  % Number of nonzero matrix elements
y=U*sqrt(S)*x;

U1=U(:,1);

U2=U(:,2);

U3=U(:,3);

for i=1:1000
x=mu+sigma*randn(3,i);
Ry=.01*(y*y');
y=U*sqrt(S)*x;
end
plot3(y(1,:),y(2,:),y(3,:),'r.')
hold on
plot(U1,'b-')
plot(U2,'b-')
plot(U3,'b-')
